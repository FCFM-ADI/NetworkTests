#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"
cd "$SCRIPT_DIR"

if type -p java; then
    echo encontramos Java en PATH
    _java=java
elif [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
    echo encontramos ejecutable en $JAVA_HOME
    _java="$JAVA_HOME/bin/java"
else
    echo "No encontramos java :("
    _install=install
fi

if [[ "$_java" ]]; then
    version=$("$_java" -version 2>&1 | awk -F '"' '/version/ {print $2}')
    echo version "$version"
    if [[ "$version" > "1.6" ]]; then
        echo version es mayor a 1.6
        java -jar ADINetworkTester.jar
    else
        echo version es menor a 1.6
        _install=install
    fi
fi
if [[ "$_install" ]]; then
    echo Para poder ejecutar el tester, debes tener Java 1.6 o superior.
    if [ "$(uname)" == "Darwin" ]; then
      read -p "Presiona [Enter] para abrir tu navegeador y bajar el entorno Java. Instálalo y luego re-intenta ejecutar este archivo"
      open http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
    else
      read -p "Por favor presiona [Enter] para terminar"
    fi
fi
